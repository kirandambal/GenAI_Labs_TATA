import os
import time
from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from azure.cognitiveservices.vision.computervision.models import OperationStatusCodes
from msrest.authentication import CognitiveServicesCredentials
import openai
from flask import Flask, request, render_template, redirect, url_for
# Add Azure OpenAI package
from openai import AzureOpenAI

app = Flask(__name__)

# Azure Cognitive Services and Azure OpenAI settings
cog_endpoint = "https://azure57941564.cognitiveservices.azure.com/"
cog_key = "9962d6f4459241f086ad49026b8f038e"
azure_oai_endpoint = "https://azureoai1484.openai.azure.com/"
azure_oai_key = "757195576a0d4630b961c25b40ed3ce4"
azure_oai_model = "Demo"

# Initialize Azure Cognitive Services client
credential = CognitiveServicesCredentials(cog_key)
cv_client = ComputerVisionClient(cog_endpoint, credential)

# Initialize OpenAI settings
openai.api_type = "azure"
openai.api_base = azure_oai_endpoint
openai.api_version = "2023-03-15-preview"
openai.api_key = azure_oai_key


@app.route("/", methods=["GET", "POST"])
def upload_image():
    if request.method == "POST":
        if "image" not in request.files:
            return redirect(request.url)

        image_file = request.files["image"]

        if image_file.filename == "":
            return redirect(request.url)

        # Save the uploaded image temporarily
        # Save the uploaded image in the "static" folder
        image_path = os.path.join(app.root_path, 'static', 'uploaded_image.jpg')
        image_file.save(image_path)
        
        # Process the image with OCR
        text_from_ocr = GetTextRead(image_path)
        text = " ".join(text_from_ocr)
        print(text)
        # Send request to Azure OpenAI model for product description
        response = gpt_openai(text)
        
        return render_template("index.html", image_path=image_path, description=response, text=text)

    return render_template("index.html", image_path=None, description=None, text=None)




def GetTextRead(image_file_path):
    print('Reading text in {}\n'.format(image_file_path))
    # Use Read API to read text in image
    # Use Read API to read text in image
    with open(image_file_path, mode="rb") as image_data:
        read_op = cv_client.read_in_stream(image_data, raw=True)

        # Get the async operation ID so we can check for the results
        operation_location = read_op.headers["Operation-Location"]
        operation_id = operation_location.split("/")[-1]

        # Wait for the asynchronous operation to complete
        while True:
            read_results = cv_client.get_read_result(operation_id)
            if read_results.status not in [OperationStatusCodes.running, OperationStatusCodes.not_started]:
                break
            time.sleep(1)

        # If the operation was successfully, process the text line by line
        ocr_text = []
        if read_results.status == OperationStatusCodes.succeeded:
            for page in read_results.analyze_result.read_results:
                for line in page.lines:
                    ocr_text.append(line.text)

    return ocr_text


def gpt_openai(text): 
    try: 
        # Initialize the Azure OpenAI client
        client = AzureOpenAI(
                azure_endpoint = azure_oai_endpoint, 
                api_key=azure_oai_key,  
                api_version="2024-02-15-preview"
                )
        # Send request to Azure OpenAI model
        response = client.chat.completions.create(
            model=azure_oai_model,
            temperature=0.7,
            max_tokens=500,
            messages=[
                    {"role": "system", "content": "Generate a product description using the following keywords detected using OCR from the image of the product: "},
                    {"role": "user", "content": text}
                ]
        )
        print(response.choices[0].message.content)
        return response.choices[0].message.content

    except Exception as ex:
        print(ex)

    except Exception as ex:
        print(ex)       


if __name__ == "__main__":
    app.run(debug=True)
